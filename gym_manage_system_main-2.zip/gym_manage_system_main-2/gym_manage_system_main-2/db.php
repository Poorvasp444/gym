<?php
$server="localhost";
$username="root";
$password="";
$database="gym";

$conn=mysqli_connect($server,$username,$password,$database);

?>