<?php

// Connect to the database
$mysqli = new mysqli("localhost", "username", "password", "gym");

// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Create a trigger to mark attendance after INSERT into the Attendance table
$query = "
    DELIMITER //
    CREATE TRIGGER after_attendance_insert AFTER INSERT ON Attendance
    FOR EACH ROW
    BEGIN
        INSERT INTO Attendance (member_id, class_id, attendance_date)
        VALUES (NEW.member_id, NEW.class_id, CURDATE());
    END;
    //
    DELIMITER ;
";

if ($mysqli->multi_query($query)) {
    do {
        // Consume all results
    } while ($mysqli->more_results() && $mysqli->next_result());
    echo "Trigger created successfully.";
} else {
    echo "Error creating trigger: " . $mysqli->error;
}

// Close the database connection
$mysqli->close();

?>